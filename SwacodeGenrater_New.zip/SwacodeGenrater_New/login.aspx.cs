﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.Cookies["Username"] != null)
            {
                txtusername.Text = Request.Cookies["Username"].Value;
            }

            if (Request.Cookies["pwd"] != null)
            {
                txtpassword.Attributes.Add("value", Request.Cookies["pwd"].Value);
            }

            if (Request.Cookies["Username"] != null && Request.Cookies["pwd"] != null)
            {
                rememberme.Checked = true;
            }

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //SqlConnection cn = new SqlConnection("server=localhost;uid=sa;pwd=virtual;database=Sample");
        //SqlConnection cn = new SqlConnection("server=SWAPNILM4-MSD\\SQLEXPRESS2008;uid=sa;pwd=password_123;database=Sample");
        //SqlConnection cn  = new SqlConnection("server=.;uid=swapnil;pwd=password_123;database=master");
        SqlConnection cn = new SqlConnection("Data Source = .; Initial Catalog = Sample; Integrated Security = SSPI;");
        SqlCommand cmd = new SqlCommand("sp_login", cn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add(new SqlParameter("@username", txtusername.Text));
        cmd.Parameters.Add(new SqlParameter("@password", txtpassword.Text));
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Session["UserId"] = dt.Rows[0]["Id"].ToString();
            if (rememberme.Checked)
            {
                Response.Cookies["Username"].Value = txtusername.Text;
                Response.Cookies["pwd"].Value = txtpassword.Text;
            }
            else
            {
                Response.Cookies["Username"].Value = null;
                Response.Cookies["pwd"].Value = null;
            }
            txtusername.Text = string.Empty;
            txtpassword.Attributes.Add("value","");
            Response.Redirect("Default2.aspx");

        }
        else
        {
            MessageBox.Show("Invalid Username/Password");
        }

    }
}