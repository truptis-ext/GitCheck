﻿//function ExecuteNonQuery(MethodURL, JsonString) {
//    $.ajax({
//        crossDomain: true,
//        type: "POST",
//        url: MethodURL,
//        data: JsonString,
//        contentType: "application/json; charset=utf-8",
//        dataType: "json",
//        async: false,
//        success: function () { },
//        error: function () { }
//    });
//}

//function ExecuteNonQueryWithSuccess(URL, strdata, onSuccess) {
//    $.ajax({
//        url: URL,
//        type: 'POST',
//        dataType: 'json',
//        crossDomain: true,
//        data: strdata,
//        success: onSuccess
//    });
//}

function ExecutenonQuery($http, url, method, async, cache, data) {
    return $http({
        url: url,
        method: method,
        async: async,
        cache: cache,
        data: data
    })
}
function setUntouched(Form) {
    angular.forEach(Form.$error, function (field) {
        angular.forEach(field, function (errorField) {
            errorField.$setUntouched();
        });
    });
}