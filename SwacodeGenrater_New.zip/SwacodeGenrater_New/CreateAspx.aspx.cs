﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Text;
public partial class CreateAspx : System.Web.UI.Page
{
    public string Database_Name;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect("login.aspx");
        }
        SqlDataAdapter da = new SqlDataAdapter("select * from sysdatabases order by name", Coneection.cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (!IsPostBack)
        {
            SwaBindcontrols.BindDropDownList(dropdatabase, ds.Tables[0], "name", "dbid");
            Bindusers();
        }
    }
    public void Bindusers()
    {

        SqlDataAdapter da = new SqlDataAdapter("Select Id, username, password, IsAdmin from tbl_user", Coneection.cn1);
        DataSet ds = new DataSet();
        da.Fill(ds);
        cmbname.DataTextField = "username";
        cmbname.DataValueField = "Id";
        cmbname.DataSource = ds.Tables[0];
        cmbname.DataBind();
        cmbname.Items.FindByValue(Session["UserId"].ToString()).Selected = true;
        //cmbname.Style.Add("disabled", "disabled");
        //cmbname.Enabled = false;
    }
    #region "------------Control Events--------------"
    protected void dropdatabase_SelectedIndexChanged(object sender, EventArgs e)
    {
        Database_Name = dropdatabase.SelectedItem.Text;
        string query = "use " + Database_Name + " select * from sys.tables order by name";
        SqlDataAdapter da = new SqlDataAdapter(query, Coneection.cn);
        DataSet dsTables = new DataSet();
        da.Fill(dsTables);
        SwaBindcontrols.BindDropDownList(Tables, dsTables.Tables[0], "name", "object_id");
    }
    protected void btngenrate_Click(object sender, EventArgs e)
    {
        string Created_By = String.Empty;
        Created_By = cmbname.SelectedItem.Text;
        if (Tables.SelectedItem == null)
        {
            MessageBox.Show("Please Select Table");
        }
        else
        {
            string Tablename = Tables.SelectedItem.Text;
            StringBuilder strresult = new StringBuilder();
            strresult.Append("<div id=\"divgrd\" runat=\"server\" class=\"container\">\n");
            strresult.Append("<div class=\"form-group\">\n");
            strresult.Append("</div>\n");
            strresult.Append("<div class=\"form-group\">\n");
            strresult.Append("Search " + Tablename + "\n");
            strresult.Append("<asp:TextBox ID=\"txtsearch\" runat=\"server\"></asp:TextBox>\n");
            strresult.Append("<asp:Button ID=\"btnsearch\" runat=\"server\" Text=\"Search\" OnClick=\"btnsearch_Click\" />\n");
            strresult.Append("<asp:Button ID=\"btnaddnew\" runat=\"server\" Text=\"Add New\" OnClick=\"btnaddnew_Click\" />\n");
            strresult.Append("</div>\n");
            strresult.Append("<asp:DataGrid ID=\"grd" + Tablename.ToLower() + "\" runat=\"server\" AutoGenerateColumns=\"False\" CssClass=\"table table-hover\"\n");
            strresult.Append("PageSize=\"10\" AllowSorting=\"true\" DataKeyNames=\"Id\" AllowPaging=\"true\" OnItemCommand=\"grd" + Tablename.ToLower() + "_ItemCommand\n");
            strresult.Append("OnPageIndexChanged=\"grd" + Tablename.ToLower() + "_PageIndexChanged\" OnSortCommand=\"grd" + Tablename.ToLower() + "_SortCommand\">\n");
            strresult.Append("<Columns>\n");
            SqlDataAdapter da = new SqlDataAdapter("use " + dropdatabase.SelectedItem.Text + " exec GetTableColumns " + Tablename, Coneection.cn);
            da.SelectCommand.Parameters.Add(new SqlParameter("@TableName", Tablename));
            DataSet ds = new DataSet();
            da.Fill(ds);
            strresult.Append("<asp:BoundColumn DataField=\"Id\" HeaderText=\"Id\" ReadOnly=\"True\" Visible=\"false\" SortExpression=\"Id\"></asp:BoundColumn>");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                string strcolumn = ds.Tables[0].Rows[i]["FK_Column"].ToString();
                strresult.Append("<asp:BoundColumn DataField=\"" + strcolumn + "\" HeaderText=\"" + strcolumn + "\" SortExpression=\"" + strcolumn + "\">\n");
                strresult.Append("</asp:BoundColumn>\n");
            }
            strresult.Append("<asp:TemplateColumn>\n");
            strresult.Append("<ItemTemplate>\n");
            strresult.Append("<asp:LinkButton ID=\"lbtnedit\" runat=\"server\" CommandName=\"Edit\">Edit</asp:LinkButton>\n");
            strresult.Append("</ItemTemplate>\n");
            strresult.Append("</asp:TemplateColumn>\n");
            strresult.Append("<asp:TemplateColumn>\n");
            strresult.Append("<ItemTemplate>\n");
            strresult.Append("<asp:LinkButton ID=\"lbtndelete\" runat=\"server\" CommandName=\"Delete\" OnClientClick=\"return confirm('Do you want to delete this record?');\">Delete</asp:LinkButton>\n");
            strresult.Append("</ItemTemplate>\n");
            strresult.Append("</asp:TemplateColumn>\n");


            strresult.Append("</Columns>\n");
            strresult.Append("<PagerStyle Mode=\"NumericPages\" CssClass=\"gridview\" HorizontalAlign=\"Right\" />\n");
            strresult.Append("</asp:DataGrid>\n");
            strresult.Append("</div>\n");

            strresult.Append("<div id=\"divform\" runat=\"server\" class=\"form-group\">\n");
            strresult.Append("<div class=\"form-group\">\n");
            strresult.Append("</div>\n");
            strresult.Append("<div class=\"form-group\">\n");
            strresult.Append("</div>\n");
            strresult.Append("<div class=\"container-fluid\">\n");
            strresult.Append("<div class=\"row\" runat=\"server\" visible=\"false\">\n");
            strresult.Append("<div class=\"col-xs-6 col-md-2\">");
            strresult.Append("Id");
            strresult.Append("</div>");
            strresult.Append("<div class=\"col-xs-6 col-md-4\">");
            strresult.Append("<asp:Label ID=\"lblid\" runat=\"server\" Text=\"Label\"></asp:Label></div>");
            strresult.Append("</div>");
            strresult.Append("</div>");

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                strresult.Append("<div class=\"row\">\n");
                strresult.Append("<div class=\"col-xs-6 col-md-2\">\n");
                strresult.Append(ds.Tables[0].Rows[i]["FK_Column"].ToString() + "\n");
                strresult.Append("</div>\n");
                strresult.Append("<div class=\"col-xs-6 col-md-4\">\n");
                if (Convert.ToInt32(ds.Tables[0].Rows[i]["Count"].ToString()) == 1)
                {

                    strresult.Append("<asp:TextBox ID=\"txt" + ds.Tables[0].Rows[i]["FK_Column"].ToString().ToLower() + "\" runat=\"server\"></asp:TextBox>\n");
                }
                else
                {
                    strresult.Append("<asp:DropDownList ID=\"ddl" + ds.Tables[0].Rows[i]["FK_Column"].ToString().ToLower() + "\" runat=\"server\"></asp:DropDownList>\n");
                }
                strresult.Append("</div>\n");
                strresult.Append("</div>\n");
            }
            strresult.Append("<div class=\"row\">\n");
            strresult.Append("<div class=\"col-xs-12 col-md-8\">\n");
            strresult.Append("<asp:Button ID=\"btnsave\" runat=\"server\" Text=\"Save\" OnClick=\"btnsave_Click\" />\n");
            strresult.Append("<asp:Button ID=\"btnupdate\" runat=\"server\" Text=\"Update\" OnClick=\"btnupdate_Click\" />\n");
            strresult.Append("<asp:Button ID=\"btnclear\" runat=\"server\" Text=\"Clear\" OnClick=\"btnclear_Click\" />\n");
            strresult.Append("<asp:Button ID=\"btncancel\" runat=\"server\" Text=\"Cancel\" OnClick=\"btncancel_Click\" />\n");
            strresult.Append("</div>\n");
            strresult.Append("</div>\n");

            strresult.Append("</div>\n");
            
            txtResult.Text = strresult.ToString();
        }


    }
    #endregion
}