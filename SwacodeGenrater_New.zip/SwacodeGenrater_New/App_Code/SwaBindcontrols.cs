﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data; 
using System.Web.UI.WebControls;  
/// <summary>
/// Summary description for SwaBindcontrols
/// </summary>
public class SwaBindcontrols
{
	public SwaBindcontrols()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static void BingGridView(GridView grv,DataTable dt)
    {
        grv.DataSource=dt;
        grv.DataBind();  
    }
    public static void BindDropDownList(DropDownList ddl, DataTable dt, string showColumn, string ValueColumn)
    {
        ddl.DataSource = dt;
        ddl.DataTextField = showColumn;
        ddl.DataValueField = ValueColumn;
        ddl.DataBind();  
    } 
}