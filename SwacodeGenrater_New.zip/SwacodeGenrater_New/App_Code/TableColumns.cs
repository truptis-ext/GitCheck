﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Collections; 
/// <summary>
/// Summary description for TableColumns
/// </summary>
public class TableColumns
{
	public TableColumns()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static ArrayList GetallColumnsnames(DataTable dt)
    {
        ArrayList arr = new ArrayList();  
        for (int i = 0; i <dt.Columns.Count;i++)
        {
            string columnName = dt.Columns[i].ColumnName.ToString();
            arr.Add(columnName);  
        }
        return arr; 
    }
}