﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.SqlClient;    
/// <summary>
/// Summary description for CreateProcedure
/// </summary>
public class CreateProcedure
{
	public CreateProcedure()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    #region SELECT ALL_SP PART
    public static string SelectAllSp(String TableName,ArrayList ColumnNames,string Created_By)
    {
        string str = string.Empty;
        str = "----------------------------------------------------"+"\n";
        str = str+"--"+ "Author - " + Created_By+"\n";
        str = str+"--" + "Stored Procedure Name -"+TableName +"SelectAllSp\n";
        str = str +"--This stored procedure is Intended to Select All records From " + TableName + "\n";
        str = str + "--------------------------------------------------" + "\n";
        str = str+"Create Procedure " + TableName + "SelectAllSp\n";
        str = str + "( \n";
        str = str + "  @Issuccess int = null"+"\n";
        str = str + ")";
        str = str + "\n" + "as"+"\n";
        str = str + "BEGIN TRY"+"\n";
        str = str + "  Begin Transaction" + "\n";
        str = str + "     " + "SELECT" + "\n";
        for (int i = 0; i < ColumnNames.Count; i++)
        {
            if (i == (ColumnNames.Count - 1))
            {
                str = str + "       " + ColumnNames[i] + "\n";
            }
            else
            {
                str = str + "       " + ColumnNames[i] + "," + "\n";
            }
        }
        str = str + "     " + "From" + "\n";
        str = str + "     " + TableName+"\n";
        str = str + "\n"+"  set @Issuccess =1"+"\n";
        str = str + "  Commit Transaction" + "\n";
        str = str + "END TRY" + "\n";
        str = str + "BEGIN Catch" + "\n";
        str = str + "  set @Issuccess =0" + "\n";
        str = str + "END Catch"+"\n";
        str = str + "GO";
        return str;
    }
    #endregion INSERT_SP PART

    #region UPDATE SP PART
    public static string GetUpdateSp(string Databasename,String TableName, ArrayList ColumnNames, string Created_By)
    {
        string str = "USe "+Databasename+" select Column_name,data_type from information_schema.columns where table_name =" + "'" + TableName + "'";
        SqlDataAdapter da = new SqlDataAdapter(str,Coneection.cn);
        DataSet ds = new DataSet();
        da.Fill(ds); 
        string Updatestr = string.Empty;
        Updatestr = "----------------------------------------------------" + "\n";
        Updatestr = Updatestr + "--" + "Author - " + Created_By + "\n";
        Updatestr = Updatestr + "--" + "Stored Procedure Name -" + TableName + "UpdateSp\n";
        Updatestr = Updatestr + "--This stored procedure is Intended to update recoeds from " + TableName + "\n";
        Updatestr = Updatestr + "--------------------------------------------------" + "\n";
        Updatestr = Updatestr+"Create Procedure " + TableName + "UpdateSp\n";
        Updatestr = Updatestr + "( \n";
        for (int i = 0; i < ColumnNames.Count; i++)
        {
            if (!ColumnNames[i].ToString().Equals("Id"))
            {
                Updatestr = Updatestr + "    " + "@" + ColumnNames[i].ToString() + "  " + ds.Tables[0].Rows[i][1].ToString() + "(max)" + "=NULL" + "," + "\n";
            }
            else
            {
                Updatestr = Updatestr + "    " + "@" + ColumnNames[i].ToString() + "  " + ds.Tables[0].Rows[i][1].ToString()+ "=NULL" + "," + "\n";
            }
            
        }
        //Updatestr = Updatestr + "  @Id        int = null" + "," + "\n";
        Updatestr = Updatestr + "    @Issuccess int = NULL" + "\n";
        Updatestr = Updatestr + ")";
        Updatestr = Updatestr + "\n" + "as" + "\n";
        Updatestr = Updatestr + "BEGIN TRY" + "\n";
        Updatestr = Updatestr + "  Begin Transaction" + "\n";
        Updatestr = Updatestr + "     " + "Update " + TableName + "\n";
        Updatestr = Updatestr + "  Set" + "\n";
        for (int i = 0; i < ColumnNames.Count;i++)
        {
            if (i>0)
           {
            if (i == (ColumnNames.Count-1))
            {
                Updatestr =Updatestr +"      "+ ColumnNames[i] + "=" + "@" + ColumnNames[i] + "\n";
            }
            else
            {
                Updatestr = Updatestr + "      " + ColumnNames[i] + "=" + "@" + ColumnNames[i] + "," + "\n";
            }
           }
        }
        Updatestr = Updatestr + "    where Id=@Id";
        Updatestr = Updatestr + "\n" + "  set @Issuccess =1" + "\n";
        Updatestr = Updatestr + "  Commit Transaction" + "\n";
        Updatestr = Updatestr + "END TRY" + "\n";
        Updatestr = Updatestr + "BEGIN Catch" + "\n";
        Updatestr = Updatestr + "  set @Issuccess =0" + "\n";
        Updatestr = Updatestr + "END Catch"+"\n";
        Updatestr = Updatestr + "GO";
        return Updatestr;
    }
    #endregion UPDATE SP PART

    #region DELETE sp PART
    public static string Delete_Sp(String TableName, ArrayList ColumnNames, string Created_By)
    {
        string Deletestr=string.Empty;
        Deletestr = "----------------------------------------------------" + "\n";
        Deletestr = Deletestr + "--" + "Author - " + Created_By + "\n";
        Deletestr = Deletestr + "--" + "Stored Procedure Name -" + TableName + "DeleteSp\n";
        Deletestr = Deletestr + "--This stored procedure is Intended to Delete recoeds from " + TableName + "\n";
        Deletestr = Deletestr + "--------------------------------------------------" + "\n";
        Deletestr = Deletestr+"Create Procedure " + TableName + "DeleteSp\n";
        Deletestr = Deletestr + "( \n";
        Deletestr = Deletestr + "  @Issuccess int = null"+"\n";
        Deletestr = Deletestr + ")";
        Deletestr = Deletestr + "\n" + "as" + "\n";
        Deletestr = Deletestr + "BEGIN TRY" + "\n";
        Deletestr = Deletestr + "  Begin Transaction" + "\n";
        Deletestr = Deletestr + "   DELETE FROM " + TableName;
        Deletestr = Deletestr + "\n" + "   set @Issuccess =1" + "\n";
        Deletestr = Deletestr + "  Commit Transaction" + "\n";
        Deletestr = Deletestr + "END TRY" + "\n";
        Deletestr = Deletestr + "BEGIN Catch" + "\n";
        Deletestr = Deletestr + "  set @Issuccess =0" + "\n";
        Deletestr = Deletestr + "END Catch" + "\n";
        Deletestr = Deletestr+"Go";
        return Deletestr;
    }
#endregion DELETE sp PART

    #region selectById
    public static string SelectById(String TableName, ArrayList ColumnNames, string Created_By)
    {
        string strselectById = string.Empty;
        strselectById = "----------------------------------------------------" + "\n";
        strselectById = strselectById + "--" + "Author - " + Created_By + "\n";
        strselectById = strselectById + "--" + "Stored Procedure Name -" + TableName + "SelectBy_IdSp\n";
        strselectById = strselectById + "--This stored procedure is Intended to select record from" + TableName + "BY Id"+"\n";
        strselectById = strselectById + "--------------------------------------------------" + "\n";
        strselectById = strselectById + "Create Procedure " + TableName + "SelectBy_IdSp\n";
        strselectById = strselectById + "( \n";
        strselectById = strselectById + "  @Id int = null," + "\n";
        strselectById = strselectById + "  @Issuccess int = null  output" + "\n";
        strselectById = strselectById + ")";
        strselectById = strselectById + "\n" + "as" + "\n";
        strselectById = strselectById + "BEGIN TRY" + "\n";
        strselectById = strselectById + "  Begin Transaction" + "\n";
        strselectById = strselectById + "     " + "SELECT" + "\n";
        for (int i = 0; i < ColumnNames.Count; i++)
        {
            if (i == (ColumnNames.Count - 1))
            {
                strselectById = strselectById + "       " + ColumnNames[i] + "\n";
            }
            else
            {
                strselectById = strselectById + "       " + ColumnNames[i] + "," + "\n";
            }
        }
        strselectById = strselectById + "     " + "From" + "\n";
        strselectById = strselectById + "     " + TableName + "\n";
        strselectById = strselectById + "        " + "Where Id = @Id"+ "\n";
        strselectById = strselectById + "\n" + "  set @Issuccess =1" + "\n";
        strselectById = strselectById + "  Commit Transaction" + "\n";
        strselectById = strselectById + "END TRY" + "\n";
        strselectById = strselectById + "BEGIN Catch" + "\n";
        strselectById = strselectById + "  set @Issuccess =0" + "\n";
        strselectById = strselectById + "END Catch"+"\n";
        strselectById = strselectById + "Go";
        return strselectById;
    }
    #endregion 

    #region DeleteBy_Id
    public static string DeleteById(String TableName, ArrayList ColumnNames, string Created_By)
    {
        string DeleteByIdstr = string.Empty;
     
        DeleteByIdstr = "----------------------------------------------------" + "\n";
        DeleteByIdstr = DeleteByIdstr + "--" + "Author - " + Created_By + "\n";
        DeleteByIdstr = DeleteByIdstr + "--" + "Stored Procedure Name -" + TableName + "DeleteBy_Id_Sp\n";
        DeleteByIdstr = DeleteByIdstr + "--This stored procedure is Intended to Delete recoeds from " + TableName +"By ID"+ "\n";
        DeleteByIdstr = DeleteByIdstr + "--------------------------------------------------" + "\n";
        DeleteByIdstr = DeleteByIdstr + "Create Procedure " + TableName + "DeleteBy_Id_Sp\n";
        DeleteByIdstr = DeleteByIdstr + "( \n";
        DeleteByIdstr = DeleteByIdstr + "  @Id int = null ,"+"\n";
        DeleteByIdstr = DeleteByIdstr + "  @Issuccess int = null  output" + "\n";
        DeleteByIdstr = DeleteByIdstr + ")";
        DeleteByIdstr = DeleteByIdstr + "\n" + "as" + "\n";
        DeleteByIdstr = DeleteByIdstr + "BEGIN TRY" + "\n";
        DeleteByIdstr = DeleteByIdstr + "  Begin Transaction" + "\n";
        DeleteByIdstr = DeleteByIdstr + "   DELETE FROM " + TableName+"\n";
        DeleteByIdstr = DeleteByIdstr + "Where Id = @Id"+"\n";
        DeleteByIdstr = DeleteByIdstr + "\n" + "   set @Issuccess =1" + "\n";
        DeleteByIdstr = DeleteByIdstr + "  Commit Transaction" + "\n";
        DeleteByIdstr = DeleteByIdstr + "END TRY" + "\n";
        DeleteByIdstr = DeleteByIdstr + "BEGIN Catch" + "\n";
        DeleteByIdstr = DeleteByIdstr + "  set @Issuccess =0" + "\n";
        DeleteByIdstr = DeleteByIdstr + "END Catch";
        DeleteByIdstr = DeleteByIdstr + "\n";
        DeleteByIdstr = DeleteByIdstr + "Go";
        return DeleteByIdstr;
    }
    #endregion DeleteBy_Id

    #region INSERT_SP

    public static string GetInsertsp(string Databasename, String TableName, ArrayList ColumnNames, string Created_By)
    {
        string str = "USe " + Databasename + " select Column_name,data_type from information_schema.columns where table_name =" + "'" + TableName + "'";
        SqlDataAdapter da = new SqlDataAdapter(str, Coneection.cn);
        DataSet ds = new DataSet();
        da.Fill(ds); 

        string Str_Insert =string.Empty;
        Str_Insert = "--------------------------------------------------" + "\n";
        Str_Insert = Str_Insert + "--" + "Author - " + Created_By + "\n";
        Str_Insert = Str_Insert + "--" + "Stored Procedure Name -" + TableName + "InserteSp\n";
        Str_Insert = Str_Insert + "--This stored procedure is Intended to Insert recoeds Into " + TableName + "\n";
        Str_Insert = Str_Insert + "--------------------------------------------------" + "\n";
        Str_Insert = Str_Insert + "Create Procedure " + TableName + "InsertSp\n";
        Str_Insert = Str_Insert + "("+"\n";
        for (int i = 0; i < ds.Tables[0].Rows.Count;i++)
        {
            if (i == ds.Tables[0].Rows.Count - 1)
            {
              Str_Insert = Str_Insert + "    " + "@" + ColumnNames[i].ToString() + "  " + ds.Tables[0].Rows[i][1].ToString() + "=NULL" +","+ "\n";
            }
            else
            {
                if (ColumnNames[i].ToString() != "Id")
                {
                    Str_Insert = Str_Insert + "    " + "@" + ColumnNames[i].ToString() + "  " + ds.Tables[0].Rows[i][1].ToString() + "=NULL" + "," + "\n";
                }
            }   
        }
        Str_Insert = Str_Insert + "    @Issuccess int = null OUTPUT" + "\n";
        Str_Insert = Str_Insert + ")" + "\n";
        Str_Insert = Str_Insert + "as" + "\n";
        Str_Insert = Str_Insert + "BEGIN TRY" + "\n";
        Str_Insert = Str_Insert + "  Begin Transaction" + "\n";
        Str_Insert = Str_Insert+"    Insert into " + TableName + "\n";
        Str_Insert =Str_Insert + "      ("+"\n";
        for (int i = 0; i < ColumnNames.Count; i++)
        {
            if (i < ColumnNames.Count-1)
            {
                if (ColumnNames[i].ToString() != "Id")
                {
                    Str_Insert = Str_Insert + "        "+ ColumnNames[i].ToString() + "," + "\n";
                }
 
            }
            else
            {
                Str_Insert = Str_Insert + "        " + ColumnNames[i].ToString() + "\n";
            }
        }
        Str_Insert = Str_Insert + "      )";
        Str_Insert = Str_Insert + "\n";
        Str_Insert = Str_Insert + "      Values" + "\n";
        Str_Insert = Str_Insert + "      ("+"\n";
        for (int i = 0; i < ColumnNames.Count; i++)
        {
            if (i < ColumnNames.Count - 1)
            {
                if (ColumnNames[i].ToString() != "Id")
                {
                    Str_Insert = Str_Insert + "        " + "@" + ColumnNames[i].ToString() + "," + "\n";
                }
            }
            else
            {
                Str_Insert = Str_Insert + "        " + "@" + ColumnNames[i].ToString() +"\n";
            }  
        }
        Str_Insert = Str_Insert + "      )" + "\n";
        Str_Insert = Str_Insert + "  Commit Transaction" + "\n";
        Str_Insert = Str_Insert + "END TRY" + "\n";
        Str_Insert = Str_Insert + "BEGIN Catch"+"\n";
        Str_Insert = Str_Insert + " --If @@Transcount > 0" + "\n";
        Str_Insert = Str_Insert + "  RollBack Transaction"+ "\n";
        Str_Insert = Str_Insert + "  set @Issuccess =0" + "\n";
        Str_Insert = Str_Insert + " END Catch"+"\n";
        Str_Insert = Str_Insert + "Go";
        return Str_Insert;

    }
    #endregion

    #region  InsertAll
    public static string Insertall(string Databasename, String TableName, ArrayList ColumnNames, string Created_By)
    {
        string str = "USe " + Databasename + " select Column_name,data_type from information_schema.columns where table_name =" + "'" + TableName + "'";
        SqlDataAdapter da = new SqlDataAdapter(str, Coneection.cn);
        DataSet ds = new DataSet();
        da.Fill(ds);

        string Str_Insert = string.Empty;
        Str_Insert = "--------------------------------------------------" + "\n";
        Str_Insert = Str_Insert + "--" + "Author - " + Created_By + "\n";
        Str_Insert = Str_Insert + "--" + "Stored Procedure Name -" + TableName + "InserteSp\n";
        Str_Insert = Str_Insert + "--This stored procedure is Intended to Insert recoeds Into " + TableName + "\n";
        Str_Insert = Str_Insert + "--------------------------------------------------" + "\n";
        Str_Insert = Str_Insert + "Create Procedure " + TableName + "InsertSp\n";
        Str_Insert = Str_Insert + "(" + "\n";
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            if (i == ds.Tables[0].Rows.Count - 1)
            {
                Str_Insert = Str_Insert + "    " + "@" + ColumnNames[i].ToString() + "  " + ds.Tables[0].Rows[i][1].ToString() + "(max)" + "=NULL" + "," + "\n";
                if (ColumnNames[i].ToString() == "varchar")
                {
                    Str_Insert = Str_Insert + "    " + "@" + ColumnNames[i].ToString() + "  " + ds.Tables[0].Rows[i][1].ToString()+"(max)" + "=NULL" + "," + "\n";
                }
            }
            else
            {
                if (ColumnNames[i].ToString() != "Id")
                {
                    if (ds.Tables[0].Rows[i][1].ToString() == "varchar")
                    {
                        Str_Insert = Str_Insert + "    " + "@" + ColumnNames[i].ToString() + "  " + ds.Tables[0].Rows[i][1].ToString() + "(max)" + "=NULL" + "," + "\n";
                    }
                    else
                    {
                        Str_Insert = Str_Insert + "    " + "@" + ColumnNames[i].ToString() + "  " + ds.Tables[0].Rows[i][1].ToString()+ "=NULL" + "," + "\n";
                    }
                }
            }
        }
        Str_Insert = Str_Insert + "    @Issuccess int = null OUTPUT" + "\n";
        Str_Insert = Str_Insert + ")" + "\n";
        Str_Insert = Str_Insert + "as" + "\n";
        Str_Insert = Str_Insert + "BEGIN TRY" + "\n";
        Str_Insert = Str_Insert + "  Begin Transaction" + "\n";
        Str_Insert = Str_Insert + "    Insert into " + TableName + "\n";
        Str_Insert = Str_Insert + "      (" + "\n";
        for (int i = 0; i < ColumnNames.Count; i++)
        {
            if (i < ColumnNames.Count - 1)
            {
                if (ColumnNames[i].ToString() != "Id")
                {
                    Str_Insert = Str_Insert + "        " + ColumnNames[i].ToString() + "," + "\n";
                }

            }
            else
            {
                Str_Insert = Str_Insert + "        " + ColumnNames[i].ToString() + "\n";
            }
        }
        Str_Insert = Str_Insert + "      )";
        Str_Insert = Str_Insert + "\n";
        Str_Insert = Str_Insert + "      Values" + "\n";
        Str_Insert = Str_Insert + "      (" + "\n";
        for (int i = 0; i < ColumnNames.Count; i++)
        {
            if (i < ColumnNames.Count - 1)
            {
                if (ColumnNames[i].ToString() != "Id")
                {
                    Str_Insert = Str_Insert + "        " + "@" + ColumnNames[i].ToString() + "," + "\n";
                }
            }
            else
            {
                Str_Insert = Str_Insert + "        " + "@" + ColumnNames[i].ToString() + "\n";
            }
        }
        Str_Insert = Str_Insert + "      )" + "\n";
        Str_Insert = Str_Insert + "  Commit Transaction" + "\n";
        Str_Insert = Str_Insert + "END TRY" + "\n";
        Str_Insert = Str_Insert + "BEGIN Catch" + "\n";
        Str_Insert = Str_Insert + " --If @@Transcount > 0" + "\n";
        Str_Insert = Str_Insert + "  RollBack Transaction" + "\n";
        Str_Insert = Str_Insert + "  set @Issuccess =0" + "\n";
        Str_Insert = Str_Insert + " END Catch" + "\n";
        Str_Insert = Str_Insert + "Go";
        return Str_Insert;
    }
    #endregion 
}