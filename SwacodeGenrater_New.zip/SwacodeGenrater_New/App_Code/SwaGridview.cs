﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
/// <summary>
/// Summary description for SwaGridview
/// </summary>
public class SwaGridview
{
	public SwaGridview()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static void Filter(GridView grv)
    {
        for (int i = 0; i <grv.Columns.Count;i++ )
        {
            string str = grv.Columns[i].HeaderText.ToString();
            str = str.Replace("_"," ");
            grv.Columns[i].HeaderText= str;
        }
    }
}