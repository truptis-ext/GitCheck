﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;    

/// <summary>
/// Summary description for Coneection
/// </summary>
public class Coneection
{
	public Coneection()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static SqlConnection cn = new SqlConnection("Data Source = .; Initial Catalog = master; Integrated Security = SSPI;");
    public static SqlConnection cn1 = new SqlConnection("Data Source = .; Initial Catalog = Sample; Integrated Security = SSPI;");

}