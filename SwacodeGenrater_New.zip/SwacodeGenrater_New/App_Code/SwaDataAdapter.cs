﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
/// <summary>
/// Summary description for SwaDataAdapter
/// </summary>
public class SwaDataAdapter
{
	public SwaDataAdapter()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static DataSet GetDatasetFromQuery(string query)
    {
        SqlDataAdapter da = new SqlDataAdapter(query, Coneection.cn);
        DataSet ds=new DataSet(); 
        da.Fill(ds);
        return ds;
    }

}