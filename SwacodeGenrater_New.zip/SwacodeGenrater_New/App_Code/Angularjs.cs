﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Text;
using BlackBeltCoder.JavaFormatter;

public class Angularjs
{
    public Angularjs()
    {
    }

    public static string GetHtml(string database, string table, ArrayList arcolumnsname)
    {
        StringBuilder strresult = new StringBuilder();
        strresult.Append("<!DOCTYPE html>\n");
        strresult.Append("<html ng-app=\"" + table + "App\">\n");
        strresult.Append("<head runat=\"server\">\n");
        strresult.Append("<title></title>\n");
        strresult.Append("</head>\n");
        strresult.Append("<body ng-controller=\"" + table + "Controller\">\n");
        strresult.Append("<div class=\"container\" ng-init=\"init();\">\n");
        strresult.Append("<div ng-show=\"!editMode\">");
        strresult.Append("\n");
        strresult.Append("<form class=\"form-inline\">");
        strresult.Append("\n");
        strresult.Append("<p style=\"margin-top: 45px;\"></p>\n");
        strresult.Append("<div class=\"input-group add-on\">\n");
        strresult.Append("<input class=\"form-control\" placeholder=\"Search\" name=\"srch-term\" id=\"srch-term\" type=\"text\" ng-model=\"searchKeyword\">\n");
        strresult.Append("<div class=\"input-group-btn\">\n");
        strresult.Append("<button class=\"btn btn-default\" type=\"submit\"><i class=\"glyphicon glyphicon-search\"></i></button>\n");
        strresult.Append("</div>\n");
        strresult.Append("</div>\n");

        strresult.Append("<a href=\"#\" class=\"btn btn-primary btn-primary\" ng-click=\"addNewRecord();\"><span class=\"glyphicon glyphicon-plus\"></span>Add New</a>\n");
        strresult.Append("<p></p>\n");
        strresult.Append("<table class=\"table table-hover\">\n");
        strresult.Append("<thead>\n");
        strresult.Append("<tr>\n");

        for (int i = 0; i < arcolumnsname.Count; i++)
        {
            strresult.Append("<th ng-click=\"sortColumn('" + arcolumnsname[i].ToString() + "')\">" + arcolumnsname[i].ToString() + "</th>\n");
        }
        strresult.Append("<th>Edit</th>\n");
        strresult.Append("<th>Delete</th>\n");
        strresult.Append("</tr>\n");
        strresult.Append("</thead>\n");
        strresult.Append("<tbody>\n");
        strresult.Append("<tr ng-repeat=\"row in rows| filter:searchKeyword | orderBy:orderByColumn:sortDirection\">\n");
        for (int i = 0; i < arcolumnsname.Count; i++)
        {
            strresult.Append("<td>{{row." + arcolumnsname[i] + "}}</td>\n");
        }
        strresult.Append("<td><a ng-click=\"edit(row);\" class=\"btn btn-warning\"><span class=\"glyphicon glyphicon-pencil\"></span></a></td>");
        strresult.Append("<td><a ng-click=\"delete(row.Id);\" class=\"btn btn-danger\"><span class=\"glyphicon glyphicon-remove\"></span></a></td>");
        strresult.Append("</tr>\n");
        strresult.Append("</tbody>\n");
        strresult.Append("</table>\n");
        strresult.Append("<div class=\"pull-right\">\n");
        strresult.Append("<select class=\"form-control\" ng-options=\"page for page in Pages\" ng-model=\"selectedPage\" ng-change=\"pageChanged()\">\n");
        strresult.Append("</select>\n");
        strresult.Append("/{{Pages.length}}\n");
        strresult.Append("</div>\n");
        strresult.Append("</form>\n");
        strresult.Append("</div>\n");
        strresult.Append("<div ng-show=\"editMode\">\n");
        strresult.Append("<form name=\"" + table + "\">\n");
        strresult.Append("<div class=\"form-horizontal\">\n");
        strresult.Append("<p style=\"margin-top: 45px;\"></p>\n");
        for (int i = 1; i < arcolumnsname.Count; i++)
        {
            strresult.Append("<div class=\"form-group\">\n");
            strresult.Append("<label class=\"col-xs-3 control-label\">" + arcolumnsname[i].ToString() + "</label>\n");
            strresult.Append("<div class=\"col-xs-4\">\n");
            strresult.Append("<input class=\"form-control\" name=\"name\" ng-model=\"" + arcolumnsname[i].ToString() + "\" required>\n");
            strresult.Append("<div class=\"col-xs-5\">\n");
            strresult.Append("<span ng-if=\"" + table + "." + arcolumnsname[i].ToString() + ".$touched && !vessel." + arcolumnsname[i].ToString() + ".$valid\" style=\"color: red\">Please Enter " + arcolumnsname[i].ToString() + "</span>\n");
            strresult.Append("</div>\n");
            strresult.Append("</div>\n");
            strresult.Append("</div>\n");

        }


        strresult.Append("<div class=\"form-group\">\n");
        strresult.Append("<label class=\"col-sm-2 control-label\"></label>\n");
        strresult.Append("<button type=\"button\" class=\"btn btn-info btn-lg\" ng-show=\"showAddButton\" ng-click=\"Save();\" ng-disabled=\"" + table + ".$invalid\">Save</button>\n");
        strresult.Append("<button type=\"button\" class=\"btn btn-info btn-lg\" ng-show=\"showUpdateButton\" ng-click=\"Update();\" ng-disabled=\"" + table + ".$invalid\">Update</button>\n");
        strresult.Append("<button type=\"button\" class=\"btn btn-info btn-lg\" ng-click=\"clear();\">Clear</button>\n");
        strresult.Append("<button type=\"button\" class=\"btn btn-info btn-lg\" ng-click=\"cancel();\">Cancel</button>\n");
        strresult.Append("</div>\n");


        strresult.Append("</div>\n");
        strresult.Append("</form>\n");
        strresult.Append("</div>\n");
        strresult.Append("</div>\n");
        strresult.Append("<style>\n");
        strresult.Append("table thead tr th {\n");
        strresult.Append("cursor: pointer;\n");
        strresult.Append("}\n");
        strresult.Append("</style>\n");
        strresult.Append("</body>\n");
        strresult.Append("</html>\n");

        return strresult.ToString();
    }

    public static string GetService(string database, string table, ArrayList arcolumnsname)
    {
        StringBuilder strresult = new StringBuilder();

        strresult.Append("app.service('httpcombinedservices', function ($http) {\n");
        strresult.Append("this.Get" + table + " = function () {\n");
        strresult.Append("return ExecutenonQuery($http, 'Default.aspx/Get" + table + "', 'POST', false, false, {});\n");
        strresult.Append("};\n");

        strresult.Append("this.Delete" + table + " = function (Id) {\n");
        strresult.Append("var myObj = { };\n");
        strresult.Append("myObj[\"Id\"] = Id;\n");
        strresult.Append("var json = JSON.stringify(myObj);\n");
        strresult.Append("return ExecutenonQuery($http, 'Default.aspx/Delete" + table + "', 'POST', false, false, json);\n");
        strresult.Append("};\n");

        strresult.Append("this.AddNew" + table + " = function (obj) {\n");
        strresult.Append("var json = JSON.stringify(obj);\n");
        strresult.Append("return ExecutenonQuery($http, 'Default.aspx/Add" + table + "', 'POST', false, false, json);\n");
        strresult.Append("};\n");


        strresult.Append("this.Update" + table + " = function (obj) {\n");
        strresult.Append("var json = JSON.stringify(obj);\n");
        strresult.Append("return ExecutenonQuery($http, 'Default.aspx/Update" + table + "', 'POST', false, false, json);\n");
        strresult.Append("}\n");

        strresult.Append("});\n");

        return strresult.ToString();
    }


    public static string GetWebMethod(string database, string table, ArrayList arcolumnsname)
    {
        StringBuilder strresult = new StringBuilder();

        strresult.Append("[WebMethod]\n");
        strresult.Append("public static string Get" + table + "()\n");
        strresult.Append("{\n");
        strresult.Append("  using (" + table + "_BL objbl = new " + table + "_BL())\n");
        strresult.Append("  {\n");
        strresult.Append("    return DataTableToJSONWithStringBuilder(objbl.Get"+table+"());\n");
        strresult.Append("  }\n");
        strresult.Append("}\n");

        strresult.Append("[WebMethod]\n");
        strresult.Append("public static string Add"+table +"(");
        for (int i = 1; i < arcolumnsname.Count; i++)
        {
            if (i == (arcolumnsname.Count-1))
            {
                strresult.Append("string " + arcolumnsname[i].ToString() + ")\n");
            }
            else
            {
                strresult.Append("string " + arcolumnsname[i].ToString() + ", ");
            }
        }
        strresult.Append("{\n");
        strresult.Append("  using (" + table + "_BL objbl = new " + table + "_BL())\n");
        strresult.Append("  {\n");
        for (int i = 1; i < arcolumnsname.Count; i++)
        {
            strresult.Append("   objbl."+arcolumnsname[i].ToString() +"=" + arcolumnsname[i].ToString()+";\n");
        }
        strresult.Append("   return objbl.Insert" + table + "(objbl).ToString();\n");
        strresult.Append("  }\n");
        strresult.Append("}\n");

        strresult.Append("[WebMethod]\n");
        strresult.Append("public static string Update" + table + "(");
        for (int i = 0; i < arcolumnsname.Count; i++)
        {
            if (i == (arcolumnsname.Count - 1))
            {
                strresult.Append("string " + arcolumnsname[i].ToString() + ")\n");
            }
            else
            {
                strresult.Append("string " + arcolumnsname[i].ToString() + ", ");
            }
        }
        strresult.Append("{\n");
        strresult.Append("  using (" + table + "_BL objbl = new " + table + "_BL())\n");
        strresult.Append("  {\n");
        for (int i = 0; i < arcolumnsname.Count; i++)
        {
            if(i==0)
            {
                strresult.Append("   objbl." + arcolumnsname[i].ToString() + "= Convert.ToInt32(" + arcolumnsname[i].ToString() + ");\n");
            }
            else
            {
                strresult.Append("   objbl." + arcolumnsname[i].ToString() + "=" + arcolumnsname[i].ToString() + ";\n");
            }
        }
        strresult.Append("   return objbl.Update" + table + "(objbl).ToString();\n");
        strresult.Append("  }\n");
        strresult.Append("}\n");

        strresult.Append("[WebMethod]\n");
        strresult.Append("public static string Delete" + table + "(string Id)\n");
        strresult.Append("{\n");
        strresult.Append("  using (" + table + "_BL objbl = new " + table + "_BL())\n");
        strresult.Append("  {\n");
        strresult.Append("    objbl.Id = Convert.ToInt32(Id);\n");
        strresult.Append("    return objbl.Delete" + table + "(objbl).ToString();\n");
        strresult.Append("  }\n");
        strresult.Append("}\n");
        return strresult.ToString();
    }

}