﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for SwaDataTable
/// </summary>
public class SwaDataTable
{
	public SwaDataTable()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static string DatatableToXml(DataTable dt)
    {
        string str = "<Table>" + "\n";
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            str = str + "  " + "<Rows>" + "\n";
            for (int j = 0; j < dt.Columns.Count; j++)
            {
                if (j > 0)
                {
                    str = str + "\n";
                }
                str = str + "    " + "<" + dt.Columns[j].ToString() + ">";
                str = str + dt.Rows[i][j].ToString();
                str = str + "</" + dt.Columns[j].ToString() + ">";
            }
            str = str + " " + "\n" + "  " + "</Rows>";
        }
        str = str + "\n";
        str = str + "</Table>";
        return str;
    }



    public static DataTable FilterGrid(DataTable dt)
    { 
        for (int i = 0; i < dt.Columns.Count;i++)
        {
            string column = dt.Columns[i].ColumnName;
            column = column.Replace("_", " ");
            dt.Columns[i].ColumnName = column;
            //string newcolumn = string.Empty;
            //for (int j = 0; j < column.Count();j++ )
            //{
            //   if (column.Substring(j, 1) == "_")
            //    {
            //        newcolumn = newcolumn + " ";
            //    }
            //    else
            //    {
            //        newcolumn = newcolumn + column.Substring(j, 1);
            //    }
            //   if (j ==column.Length)
            //    {
            //        dt.Columns[i].ColumnName = newcolumn;
            //    }
            //}
        }
        return dt;
    }
}