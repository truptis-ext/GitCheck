﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Text;

public partial class DAL : System.Web.UI.Page
{
    public string Database_Name;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect("login.aspx");
        }
        diverrormessage.Visible = false;
        SqlDataAdapter da = new SqlDataAdapter("select * from sysdatabases order by name", Coneection.cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (!IsPostBack)
        {
            SwaBindcontrols.BindDropDownList(dropdatabase, ds.Tables[0], "name", "dbid");
            Bindusers();
        }
    }
    public void Bindusers()
    {

        SqlDataAdapter da = new SqlDataAdapter("Select Id, username, password, IsAdmin from tbl_user", Coneection.cn1);
        DataSet ds = new DataSet();
        da.Fill(ds);
        cmbname.DataTextField = "username";
        cmbname.DataValueField = "Id";
        cmbname.DataSource = ds.Tables[0];
        cmbname.DataBind();
        cmbname.Items.FindByValue(Session["UserId"].ToString()).Selected = true;
        //cmbname.Style.Add("disabled", "disabled");
        //cmbname.Enabled = false;
    }
    public void CheckProcedureIfExists()
    {
        string strtablename = Tables.SelectedItem.Text;
        int i = 1;
        string query = "use " + dropdatabase.SelectedItem.Text + " select * from information_schema.parameters where specific_name='" + strtablename + "InsertSp'";
        SqlCommand cmd = new SqlCommand(query, Coneection.cn);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count == 0)
        {
            lblmessage.Text = "Following Stored Procedures are missing in Database<br />" + i.ToString() +") " +strtablename + "InsertSp";
            diverrormessage.Visible = true;
            i++;
        }
        query = "use " + dropdatabase.SelectedItem.Text + " select * from information_schema.parameters where specific_name='" + strtablename + "UpdateSp'";
        cmd = new SqlCommand(query, Coneection.cn);
        da = new SqlDataAdapter(cmd);
        dt.Clear();
        da.Fill(dt);
        if (dt.Rows.Count == 0)
        {
            lblmessage.Text = lblmessage.Text + "<br />" + i.ToString() + ") " + strtablename + "UpdateSp";
            diverrormessage.Visible = true;
        }
    }
    protected void dropdatabase_SelectedIndexChanged(object sender, EventArgs e)
    {
        Database_Name = dropdatabase.SelectedItem.Text;
        string query = "use " + Database_Name + " select * from sys.tables order by name";
        SqlDataAdapter da = new SqlDataAdapter(query, Coneection.cn);
        DataSet dsTables = new DataSet();
        da.Fill(dsTables);
        SwaBindcontrols.BindDropDownList(Tables, dsTables.Tables[0], "name", "object_id");
    }
    protected void btngenrate_Click(object sender, EventArgs e)
    {
        if (Tables.SelectedItem == null)
        {
            MessageBox.Show("Please Select Table");
            return;
        }
        CheckProcedureIfExists();
        string strtablename = Tables.SelectedItem.Text;

        StringBuilder strresult = new StringBuilder();
        strresult.Append("using System;\n");
        strresult.Append("using System.Collections.Generic;\n");
        strresult.Append("using System.Linq;\n");
        strresult.Append("using System.Web;\n");
        strresult.Append("using System.Data;\n");
        strresult.Append("using System.Data.SqlClient;\n\n\n");


        strresult.Append("public class " + strtablename + "_DL");
        strresult.Append("\n{\n");


        strresult.Append(" public " + strtablename + "_DL()\n");
        strresult.Append("  {\n");
        strresult.Append("  }\n\n");

        #region "Code For SelectAll Function"
        strresult.Append(" public DataTable Get" + strtablename + "()\n");
        strresult.Append("  {\n");
        strresult.Append("   DataTable dt = new DataTable();\n");
        strresult.Append("   try\n");
        strresult.Append("   {\n");
        strresult.Append(@"     SqlDataAdapter da = new SqlDataAdapter(""" + strtablename + @"SelectAllSp""" + ", Coneection.cn);\n");
        strresult.Append("      Coneection.cn.Open();\n");
        strresult.Append("    da.SelectCommand.CommandType = CommandType.StoredProcedure;\n");
        strresult.Append("    da.Fill(dt);\n");
        strresult.Append("    return dt;\n");
        strresult.Append("   }\n");
        strresult.Append("  catch (Exception ex)\n");
        strresult.Append("   {\n");
        strresult.Append("     return dt;\n");
        strresult.Append("   }\n");
        strresult.Append("  finally\n");
        strresult.Append("   {\n");
        strresult.Append("     Coneection.cn.Close();\n");
        strresult.Append("   }\n");
        strresult.Append("}\n");
        #endregion

        #region "Code For SelectById Function"
        strresult.Append(" public DataTable Get" + strtablename + "(" + strtablename + "_BL obj" + strtablename + ")\n");
        strresult.Append("  {\n");
        strresult.Append("   DataTable dt = new DataTable();\n");
        strresult.Append("   try\n");
        strresult.Append("   {\n");
        strresult.Append(@"     SqlDataAdapter da = new SqlDataAdapter(""" + strtablename + @"SelectBy_IdSp""" + ", Coneection.cn);\n");
        strresult.Append("      Coneection.cn.Open();\n");
        strresult.Append(@"     da.SelectCommand.Parameters.Add(new SqlParameter(""");
        strresult.Append(@"@Id""");
        strresult.Append(",obj" + strtablename + ".Id));\n");

        strresult.Append("      int Issuccess = 0;\n");
        strresult.Append(@"     da.SelectCommand.Parameters.Add(new SqlParameter(@""" + "Issuccess" + @""", Issuccess));");
        strresult.Append("\n");
        strresult.Append(@"     da.SelectCommand.Parameters[@""" + "Issuccess" + @"""].Direction = ParameterDirection.Output;");
        strresult.Append("\n");
        strresult.Append("     da.SelectCommand.CommandType = CommandType.StoredProcedure;\n");
        strresult.Append("     da.Fill(dt);\n");
        strresult.Append("     return dt;\n");
        strresult.Append("   }\n");
        strresult.Append("  catch (Exception ex)\n");
        strresult.Append("   {\n");
        strresult.Append("     return dt;\n");
        strresult.Append("   }\n");
        strresult.Append("  finally\n");
        strresult.Append("   {\n");
        strresult.Append("     Coneection.cn.Close();\n");
        strresult.Append("   }\n");
        strresult.Append("}\n");

        #endregion

        #region"Code For DeleteAll Function"
        strresult.Append(" public int Delete" + strtablename + "()\n");
        strresult.Append("  {\n");
        strresult.Append("   try\n");
        strresult.Append("    {\n");
        strresult.Append(@"    SqlCommand cmd = new SqlCommand(""" + strtablename + "DeleteSp" + @""", Coneection.cn);");
        strresult.Append("\n      Coneection.cn.Open();\n");
        strresult.Append("\n");
        strresult.Append("     cmd.CommandType = CommandType.StoredProcedure;\n");
        strresult.Append("     return cmd.ExecuteNonQuery();");
        strresult.Append("    }");
        strresult.Append("   catch (Exception ex)");
        strresult.Append("    {\n");
        strresult.Append("    return 0;\n");
        strresult.Append("    }\n");
        strresult.Append("   finally\n");
        strresult.Append("    {\n");
        strresult.Append("     Coneection.cn.Close();\n");
        strresult.Append("    }\n");
        strresult.Append("  }\n");
        #endregion

        #region"Code For Delete By ID Function"
        strresult.Append(" public int Delete" + strtablename + "(" + strtablename + "_BL obj" + strtablename + ")\n");
        strresult.Append("  {\n");
        strresult.Append("   try\n");
        strresult.Append("    {\n");
        strresult.Append(@"    SqlCommand cmd = new SqlCommand(""" + strtablename + "DeleteBy_Id_Sp" + @""", Coneection.cn);");
        strresult.Append("\n      Coneection.cn.Open();\n");
        strresult.Append("\n");
        strresult.Append("     cmd.CommandType = CommandType.StoredProcedure;\n");
        strresult.Append(@"     cmd.Parameters.Add(new SqlParameter(""");
        strresult.Append(@"@Id""");
        strresult.Append(",obj" + strtablename + ".Id));\n");

        strresult.Append("      int Issuccess = 0;\n");
        strresult.Append(@"     cmd.Parameters.Add(new SqlParameter(@""" + "Issuccess" + @""", Issuccess));");
        strresult.Append("\n");
        strresult.Append(@"     cmd.Parameters[@""" + "Issuccess" + @"""].Direction = ParameterDirection.Output;");
        strresult.Append("\n");
        strresult.Append("     cmd.CommandType = CommandType.StoredProcedure;\n");
        strresult.Append("     return cmd.ExecuteNonQuery();\n");
        strresult.Append("    }\n");
        strresult.Append("   catch (Exception ex)\n");
        strresult.Append("    {\n");
        strresult.Append("    return 0;\n");
        strresult.Append("    }\n");
        strresult.Append("   finally\n");
        strresult.Append("    {\n");
        strresult.Append("     Coneection.cn.Close();\n");
        strresult.Append("    }\n");
        strresult.Append("  }\n");
        #endregion

        #region"Code For Insert Function"
        strresult.Append(" public int Insert" + strtablename + "(" + strtablename + "_BL obj" + strtablename + ")\n");
        strresult.Append("  {\n");
        strresult.Append("   try\n");
        strresult.Append("    {\n");
        strresult.Append(@"     SqlCommand cmd = new SqlCommand(""" + strtablename + "InsertSp" + @""", Coneection.cn);");
        strresult.Append("\n      Coneection.cn.Open();\n");
        strresult.Append("\n");
        strresult.Append("     cmd.CommandType = CommandType.StoredProcedure;\n");
        string query = "use " + dropdatabase.SelectedItem.Text + " select * from information_schema.parameters where specific_name='" + strtablename + "InsertSp'";
        DataSet ds = new DataSet();
        ds = SwaDataAdapter.GetDatasetFromQuery(query);
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            string strparam = ds.Tables[0].Rows[i]["PARAMETER_NAME"].ToString();
            if (strparam.Equals("@Issuccess"))
            {
                strresult.Append(@"int Issuccess = 0;");
                strresult.Append("\n");
                strresult.Append(@"     cmd.Parameters.Add(new SqlParameter(""" + strparam + @"""," + strparam.Replace("@", string.Empty).ToString() + "));");
            }
            else
            {
                strresult.Append(@"     cmd.Parameters.Add(new SqlParameter(""" + strparam + @"""," + "obj" + strtablename + "." + strparam.Replace("@", string.Empty).ToString() + "));");
            }
            strresult.Append("\n");
            if (ds.Tables[0].Rows[i]["PARAMETER_MODE"].ToString().Equals("INOUT"))
            {
                strresult.Append(@"cmd.Parameters[""" + strparam + @"""].Direction = ParameterDirection.Output;");
                strresult.Append("\n");
            }

        }
        strresult.Append("     return cmd.ExecuteNonQuery();\n");
        strresult.Append("    }");
        strresult.Append("   catch (Exception ex)\n");
        strresult.Append("    {\n");
        strresult.Append("    return 0;\n");
        strresult.Append("    }\n");
        strresult.Append("   finally\n");
        strresult.Append("    {\n");
        strresult.Append("     Coneection.cn.Close();\n");
        strresult.Append("    }\n");
        strresult.Append("  }\n");
        #endregion

        #region"Code For Update Function"
        strresult.Append(" public int Update" + strtablename + "(" + strtablename + "_BL obj" + strtablename + ")\n");
        strresult.Append("  {\n");
        strresult.Append("   try\n");
        strresult.Append("    {\n");
        strresult.Append(@"     SqlCommand cmd = new SqlCommand(""" + strtablename + "UpdateSp" + @""", Coneection.cn);");
        strresult.Append("\n      Coneection.cn.Open();\n");
        strresult.Append("\n");
        strresult.Append("     cmd.CommandType = CommandType.StoredProcedure;\n");
        query = "use " + dropdatabase.SelectedItem.Text + " select * from information_schema.parameters where specific_name='" + strtablename + "UpdateSp'";
        ds = new DataSet();
        ds = SwaDataAdapter.GetDatasetFromQuery(query);
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            string strparam = ds.Tables[0].Rows[i]["PARAMETER_NAME"].ToString();
            if (strparam.Equals("@Issuccess"))
            {
                strresult.Append(@"int Issuccess = 0;");
                strresult.Append("\n");
                strresult.Append(@"     cmd.Parameters.Add(new SqlParameter(""" + strparam + @"""," + strparam.Replace("@", string.Empty).ToString() + "));");
            }
            else
            {
                strresult.Append(@"     cmd.Parameters.Add(new SqlParameter(""" + strparam + @"""," + "obj" + strtablename + "." + strparam.Replace("@", string.Empty).ToString() + "));");
            }
            strresult.Append("\n");
            if (ds.Tables[0].Rows[i]["PARAMETER_MODE"].ToString().Equals("INOUT"))
            {
                strresult.Append(@"cmd.Parameters[""" + strparam + @"""].Direction = ParameterDirection.Output;");
                strresult.Append("\n");
            }

        }
        strresult.Append("     return cmd.ExecuteNonQuery();\n");
        strresult.Append("    }");
        strresult.Append("   catch (Exception ex)\n");
        strresult.Append("    {\n");
        strresult.Append("    return 0;\n");
        strresult.Append("    }\n");
        strresult.Append("   finally\n");
        strresult.Append("    {\n");
        strresult.Append("     Coneection.cn.Close();\n");
        strresult.Append("    }\n");
        strresult.Append("  }\n");
        #endregion
        strresult.Append("\n}\n");
        txtResult.Text = strresult.ToString();
    }
}