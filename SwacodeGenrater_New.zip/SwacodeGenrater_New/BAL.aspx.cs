﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Text;

public partial class BAL : System.Web.UI.Page
{
    public string Database_Name;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect("login.aspx");
        }
        SqlDataAdapter da = new SqlDataAdapter("select * from sysdatabases order by name", Coneection.cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (!IsPostBack)
        {
            SwaBindcontrols.BindDropDownList(dropdatabase, ds.Tables[0], "name", "dbid");
            Bindusers();
        }
    }
    protected void dropdatabase_SelectedIndexChanged(object sender, EventArgs e)
    {
        Database_Name = dropdatabase.SelectedItem.Text;
        string query = "use " + Database_Name + " select * from sys.tables order by name";
        SqlDataAdapter da = new SqlDataAdapter(query, Coneection.cn);
        DataSet dsTables = new DataSet();
        da.Fill(dsTables);
        SwaBindcontrols.BindDropDownList(Tables, dsTables.Tables[0], "name", "object_id");
    }

    public void Bindusers()
    {

        SqlDataAdapter da = new SqlDataAdapter("Select Id, username, password, IsAdmin from tbl_user", Coneection.cn1);
        DataSet ds = new DataSet();
        da.Fill(ds);
        cmbname.DataTextField = "username";
        cmbname.DataValueField = "Id";
        cmbname.DataSource = ds.Tables[0];
        cmbname.DataBind();
        cmbname.Items.FindByValue(Session["UserId"].ToString()).Selected = true;
        //cmbname.Style.Add("disabled", "disabled");
        //cmbname.Enabled = false;
    }
    protected void btngenrate_Click(object sender, EventArgs e)
    {
        Database_Name = dropdatabase.SelectedItem.Text;
        if (Tables.SelectedItem == null)
        {
            MessageBox.Show("Please Select Table");
            return;
        }
        string strtablename = Tables.SelectedItem.Text;
        StringBuilder strresult = new StringBuilder();
        strresult.Append("using System;\n");
        strresult.Append("using System.Collections.Generic;\n");
        strresult.Append("using System.Linq;\n");
        strresult.Append("using System.Web;\n");
        strresult.Append("using System.Data;\n");
        strresult.Append("\n");
        strresult.Append("public class " + strtablename + "_BL:IDisposable");
        strresult.Append("\n{\n");


        strresult.Append(" public " + strtablename + "_BL()\n");
        strresult.Append("  {\n");
        strresult.Append("  }\n\n");

        string query = "use " + Database_Name + " exec sp_columns " + strtablename;
        SqlDataAdapter da = new SqlDataAdapter(query, Coneection.cn);
        DataSet dsTables = new DataSet();
        da.Fill(dsTables);
        
        strresult.Append(strtablename + "_DL objdl = new " + strtablename + "_DL();");
        strresult.Append("\n");
        strresult.Append(@" #region """"Properties""");
        strresult.Append("\n");
        for (int i = 0; i < dsTables.Tables[0].Rows.Count; i++)
        {
            string datatype = dsTables.Tables[0].Rows[i]["TYPE_NAME"].ToString().Split(' ')[0];
            if (datatype.Equals("text"))
            {
                datatype = "string";
            }
            else if (datatype.Equals("datetime"))
            {
                datatype = "DateTime";
            }
            else if (datatype.Equals("bit"))
            {
                datatype = "bool";
            }
            
            string colname = dsTables.Tables[0].Rows[i]["COLUMN_NAME"].ToString().Split(' ')[0];
            strresult.Append("   private " + datatype + " _" + colname + ";\n");
            strresult.Append("    public " + datatype + " " + colname + "\n");
            strresult.Append("      {" + "\n");
            strresult.Append("       get{ return _" + colname + ";}" + "\n");
            strresult.Append("       set{ _" + colname + "=value;}" + "\n");
            strresult.Append("      }" + "\n");
            strresult.Append("\n");
        }
        strresult.Append(@"#endregion");
        strresult.Append("\n");
        strresult.Append("   public DataTable Get" + strtablename + "()\n");
        strresult.Append("    {\n");
        strresult.Append("     return objdl.Get" + strtablename + "();\n");
        strresult.Append("    }\n");

        strresult.Append("   public DataTable Get" + strtablename + "(" + strtablename + "_BL " + "objbl)\n");
        strresult.Append("    {\n");
        strresult.Append("     return objdl.Get" + strtablename + "(objbl);\n");
        strresult.Append("    }\n");

        strresult.Append("   public int Delete" + strtablename + "()\n");
        strresult.Append("    {\n");
        strresult.Append("     return objdl.Delete"+strtablename+"();\n");
        strresult.Append("    }\n");

        strresult.Append("   public int Delete" + strtablename + "(" + strtablename + "_BL objbl)\n");
        strresult.Append("    {\n");
        strresult.Append("     return objdl.Delete" + strtablename + "(objbl);\n");
        strresult.Append("    }\n");

        strresult.Append("   public int Insert" + strtablename + "(" + strtablename + "_BL objbl)\n");
        strresult.Append("    {\n");
        strresult.Append("     return objdl.Insert" + strtablename + "(objbl);\n");
        strresult.Append("    }\n");

        strresult.Append("   public int Update" + strtablename + "(" + strtablename + "_BL objbl)\n");
        strresult.Append("    {\n");
        strresult.Append("     return objdl.Update" + strtablename + "(objbl);\n");
        strresult.Append("    }\n");
        
        strresult.Append("\n");


        strresult.Append("    public void Dispose()");
        strresult.Append("     {");
        strresult.Append("     }");
        strresult.Append(" }" + "\n");
        txtResult.Text = strresult.ToString();

    }
}