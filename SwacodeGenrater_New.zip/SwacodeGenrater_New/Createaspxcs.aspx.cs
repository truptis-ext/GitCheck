﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Text;


public partial class js_Createaspxcs : System.Web.UI.Page
{
    public string Database_Name;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect("login.aspx");
        }
        SqlDataAdapter da = new SqlDataAdapter("select * from sysdatabases order by name", Coneection.cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (!IsPostBack)
        {
            SwaBindcontrols.BindDropDownList(dropdatabase, ds.Tables[0], "name", "dbid");
            Bindusers();
        }
    }

    public void Bindusers()
    {

        SqlDataAdapter da = new SqlDataAdapter("Select Id, username, password, IsAdmin from tbl_user", Coneection.cn1);
        DataSet ds = new DataSet();
        da.Fill(ds);
        cmbname.DataTextField = "username";
        cmbname.DataValueField = "Id";
        cmbname.DataSource = ds.Tables[0];
        cmbname.DataBind();
        cmbname.Items.FindByValue(Session["UserId"].ToString()).Selected = true;
        //cmbname.Style.Add("disabled", "disabled");
        //cmbname.Enabled = false;
    }
    #region "------------Control Events--------------"
    protected void dropdatabase_SelectedIndexChanged(object sender, EventArgs e)
    {
        Database_Name = dropdatabase.SelectedItem.Text;
        string query = "use " + Database_Name + " select * from sys.tables order by name";
        SqlDataAdapter da = new SqlDataAdapter(query, Coneection.cn);
        DataSet dsTables = new DataSet();
        da.Fill(dsTables);
        SwaBindcontrols.BindDropDownList(Tables, dsTables.Tables[0], "name", "object_id");
    }
    protected void btngenrate_Click(object sender, EventArgs e)
    {
        string Created_By = String.Empty;
        Created_By = cmbname.SelectedItem.Text;
        if (Tables.SelectedItem == null)
        {
            MessageBox.Show("Please Select Table");
        }
        else
        {
            string Tablename = Tables.SelectedItem.Text;
            StringBuilder strresult = new StringBuilder();
            strresult.Append("using System;\n");
            strresult.Append("using System.Collections.Generic;\n");
            strresult.Append("using System.Linq;\n");
            strresult.Append("using System.Web;\n");
            strresult.Append("using System.Web.UI;\n");
            strresult.Append("using System.Web.UI.WebControls;\n");
            strresult.Append("using System.Web.UI.HtmlControls;\n");
            strresult.Append("using System.Collections;\n");
            strresult.Append("using System.Data;\n");
            strresult.Append("\n");
            strresult.Append("public partial class _" + Tablename + ": System.Web.UI.Page\n");
            strresult.Append(" {\n");
            strresult.Append("   protected void Page_PreInit(object sender, EventArgs e)\n");
            strresult.Append("   {\n");
            strresult.Append("    this.Theme = \"SkinFile\";");
            strresult.Append("     \n");
            strresult.Append("   }\n");
            strresult.Append("   protected void Page_Load(object sender, EventArgs e)\n");
            strresult.Append("   {\n");
            strresult.Append("     if (!IsPostBack)\n");
            strresult.Append("       {\n");
            strresult.Append("         ShowDiv(\"ShowGrid\", false);");
            strresult.Append("\n");
            strresult.Append("         Session[\"SortDirection\"] = \"DESC\";");
            strresult.Append("\n");
            strresult.Append("         //===============\n");
            strresult.Append("         GridBind();");
            strresult.Append("\n");
            strresult.Append("         //===============\n");

            strresult.Append("      }\n");
            strresult.Append("   }\n");
            strresult.Append("public void GridBind(string SortExpression = \"\")");
            strresult.Append("\n");
            strresult.Append("{\n");
            strresult.Append(" using(" + Tablename + "_BL obj= new " + Tablename + "_BL())\n");
            strresult.Append(" {\n");

            strresult.Append("  DataView dv = obj.Get" + Tablename + "().DefaultView;\n");
            strresult.Append("  if (Session[\"SortDirection\"].ToString().Equals(\"DESC\"))\n");
            strresult.Append("   {\n");
            strresult.Append("    Session[\"SortDirection\"] = \"ASC\";");
            strresult.Append("\n");
            strresult.Append("   }\n");
            strresult.Append("  else\n");
            strresult.Append("  {\n");
            strresult.Append("    Session[\"SortDirection\"] = \"DESC\";\n");
            strresult.Append("  }\n");
            strresult.Append("  if (!SortExpression.Equals(string.Empty))\n");
            strresult.Append("  {\n");
            strresult.Append("   dv.Sort = SortExpression + \" \" + Session[\"SortDirection\"].ToString();\n");
            strresult.Append("  }\n");
            strresult.Append(" grd" + Tablename.ToLower() + ".DataSource = dv;\n");
            strresult.Append(" grd" + Tablename.ToLower() + ".DataBind();\n");
            strresult.Append(" }\n");
            strresult.Append("}\n");

            strresult.Append("public void ShowDiv(string str, bool IsSave)\n");
            strresult.Append("{\n");
            strresult.Append(" if (str.Equals(\"Add_New\"))");
            strresult.Append("\n");
            strresult.Append(" {\n");
            strresult.Append("  divform.Visible = true;\n");
            strresult.Append("  divgrd.Visible = false;\n");
            strresult.Append("  if (IsSave)\n");
            strresult.Append("  {\n");
            strresult.Append("   btnsave.Visible = true;\n");
            strresult.Append("   btnupdate.Visible = false;\n");
            strresult.Append("  }\n");
            strresult.Append("  else\n");
            strresult.Append("  {\n");
            strresult.Append("   btnsave.Visible = false;\n");
            strresult.Append("   btnupdate.Visible = true;\n");
            strresult.Append("  }\n");
            strresult.Append("  }\n");
            strresult.Append("  else\n");
            strresult.Append("  {\n");
            strresult.Append("   divform.Visible = false;\n");
            strresult.Append("   divgrd.Visible = true;\n");
            strresult.Append("  }\n");
            strresult.Append("}\n");

            strresult.Append("public void SetEditControls(int RowId)\n");
            strresult.Append("{\n");
            strresult.Append("  lblid.Text = grd" + Tablename.ToLower() + ".Items[RowId].Cells[0].Text.ToString();\n");

            SqlDataAdapter da = new SqlDataAdapter("use " + dropdatabase.SelectedItem.Text + " exec GetTableColumns " + Tablename, Coneection.cn);
            da.SelectCommand.Parameters.Add(new SqlParameter("@TableName", Tablename));
            DataSet ds = new DataSet();
            da.Fill(ds);

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                string strcolumn = ds.Tables[0].Rows[i]["FK_Column"].ToString();
                if (Convert.ToInt32(ds.Tables[0].Rows[i]["Count"].ToString()) > 1)
                {
                    strresult.Append("  ddl" + strcolumn.ToLower() + ".SelectedItem.Text = grd" + Tablename.ToLower() + ".Items[RowId].Cells[" + (i + 1).ToString() + "].Text.ToString();\n");
                }
                else
                {
                    strresult.Append("  txt" + strcolumn.ToLower() + ".Text = grd" + Tablename.ToLower() + ".Items[RowId].Cells[" + (i + 1).ToString() + "].Text.ToString();\n");
                }
            }
            strresult.Append("}\n");

            strresult.Append("public void Reset()\n");
            strresult.Append("{\n");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                string strcolumn = ds.Tables[0].Rows[i]["FK_Column"].ToString();
                if (Convert.ToInt32(ds.Tables[0].Rows[i]["Count"].ToString()) > 1)
                {
                    strresult.Append("  ddl" + strcolumn.ToLower() + ".SelectedIndex = - 1;\n");
                }
                else
                {
                    strresult.Append("  txt" + strcolumn.ToLower() + ".Text = string.Empty;\n");
                }
            }
            strresult.Append("}\n");

            strresult.Append("protected void btncancel_Click(object sender, EventArgs e)\n");
            strresult.Append("{\n");
            strresult.Append("//===============\n");
            strresult.Append("ShowDiv(\"ShowGrid\", false);\n");
            strresult.Append("//===============\n");
            strresult.Append("Reset();\n");
            strresult.Append("//===============\n");
            strresult.Append("}\n");


            strresult.Append("protected void btnsearch_Click(object sender, EventArgs e)\n");
            strresult.Append("{\n");
            strresult.Append(" using(" + Tablename + "_BL obj = new " + Tablename + "_BL())\n");
            strresult.Append(" {\n");
            strresult.Append("  ArrayList arr = new ArrayList();\n");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                string strcolumn = ds.Tables[0].Rows[i]["FK_Column"].ToString();
                if (Convert.ToInt32(ds.Tables[0].Rows[i]["Count"].ToString()) == 1)
                {
                    strresult.Append("  arr.Add(\"" + strcolumn + "\");\n");
                }
            }
            strresult.Append("  grd" + Tablename.ToLower() + ".CurrentPageIndex = 0;\n");
            strresult.Append("  grd" + Tablename.ToLower() + ".DataSource = CommonFunctions.SearchDataTable(txtsearch.Text, arr, obj.Get" + Tablename + "());\n");
            strresult.Append("  grd" + Tablename.ToLower() + ".DataBind();\n");
            strresult.Append(" }\n");
            strresult.Append("}\n");

            strresult.Append("protected void btnaddnew_Click(object sender, EventArgs e)\n");
            strresult.Append("{\n");
            strresult.Append("ShowDiv(\"Add_New\", true);\n");
            strresult.Append("}\n");

            strresult.Append("protected void grd" + Tablename.ToLower() + "_ItemCommand(object source, DataGridCommandEventArgs e)\n");
            strresult.Append("{\n");
            strresult.Append("  if (e.CommandName.ToString().Equals(\"Edit\"))\n");
            strresult.Append("   {\n");
            strresult.Append("    ShowDiv(\"Add_New\", false);\n");
            strresult.Append("    SetEditControls(e.Item.ItemIndex);\n");
            strresult.Append("   }\n");
            strresult.Append("  else if (e.CommandName.ToString().Equals(\"Delete\"))");
            strresult.Append("   \n");
            strresult.Append("   {\n");
            strresult.Append("     using(" + Tablename + "_BL objbl = new " + Tablename + "_BL())\n");
            strresult.Append("     {\n");
            strresult.Append("      objbl.Id = Convert.ToInt32(grd" + Tablename.ToLower() + ".Items[e.Item.ItemIndex].Cells[0].Text.ToString());\n");
            strresult.Append("      objbl.Delete" + Tablename + "(objbl);\n");
            strresult.Append("      //====================================\n");
            strresult.Append("      GridBind();\n");
            strresult.Append("     //====================================\n");
            strresult.Append("     }\n");
            strresult.Append("   }\n");
            strresult.Append("}\n");
            strresult.Append("protected void btnsave_Click(object sender, EventArgs e)\n");
            strresult.Append("{\n");
            strresult.Append("     using(" + Tablename + "_BL objbl = new " + Tablename + "_BL())\n");
            strresult.Append("     {\n");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                string strcolumn = ds.Tables[0].Rows[i]["FK_Column"].ToString();
                if (Convert.ToInt32(ds.Tables[0].Rows[i]["Count"].ToString()) == 1)
                {
                    strresult.Append("      objbl." + strcolumn + " = txt" + strcolumn.ToLower() + ".Text.ToString();\n");
                }
                else
                {
                    strresult.Append("      objbl." + strcolumn + " = Convert.ToInt32(ddl" + strcolumn.ToLower() + ".SelectedItem.Value);\n");
                }
            }
            strresult.Append("      //============================\n");
            strresult.Append("      int result = objbl.Insert" + Tablename + "(objbl);\n");
            strresult.Append("      //============================\n");
            strresult.Append("      ShowDiv(\"ShowGrid\", false);");
            strresult.Append("\n");
            strresult.Append("      //===============\n");
            strresult.Append("      GridBind();\n");
            strresult.Append("      //===============\n");
            strresult.Append("      Reset();\n");
            strresult.Append("      //===============\n");


            strresult.Append("     }\n");
            strresult.Append("}\n");
            strresult.Append("protected void btnclear_Click(object sender, EventArgs e)\n");
            strresult.Append("{\n");
            strresult.Append("  //===============\n");
            strresult.Append("  Reset();\n");
            strresult.Append("  //===============\n");
            strresult.Append("}\n");

            strresult.Append("protected void btnupdate_Click(object sender, EventArgs e)\n");
            strresult.Append("{\n");
            strresult.Append("     using(" + Tablename + "_BL objbl = new " + Tablename + "_BL())\n");
            strresult.Append("     {\n");
            strresult.Append("      objbl.Id = Convert.ToInt32(lblid.Text.ToString());\n");
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                string strcolumn = ds.Tables[0].Rows[i]["FK_Column"].ToString();
                if (Convert.ToInt32(ds.Tables[0].Rows[i]["Count"].ToString()) == 1)
                {
                    strresult.Append("      objbl." + strcolumn + " = txt" + strcolumn.ToLower() + ".Text.ToString();\n");
                }
                else
                {
                    strresult.Append("      objbl." + strcolumn + " = Convert.ToInt32(ddl" + strcolumn.ToLower() + ".SelectedItem.Value);\n");
                }
            }
            strresult.Append("      //============================\n");
            strresult.Append("      int result = objbl.Update" + Tablename + "(objbl);\n");
            strresult.Append("      //============================\n");
            strresult.Append("      ShowDiv(\"ShowGrid\", false);");
            strresult.Append("\n");
            strresult.Append("      //===============\n");
            strresult.Append("      GridBind();\n");
            strresult.Append("      //===============\n");
            strresult.Append("      Reset();\n");
            strresult.Append("      //===============\n");
            strresult.Append("     }\n");
            strresult.Append("}\n");
            strresult.Append("protected void grd"+Tablename.ToLower()+"_PageIndexChanged(object source, DataGridPageChangedEventArgs e)\n");
            strresult.Append("{\n");
            strresult.Append(" grd"+Tablename.ToLower()+".CurrentPageIndex = e.NewPageIndex;\n");
            strresult.Append(" if (Session[\"SortDirection\"].ToString().Equals(\"DESC\"))");
            strresult.Append("\n");
            strresult.Append("  {\n");
            strresult.Append("   Session[\"SortDirection\"] = \"ASC\";");
            strresult.Append("\n");
            strresult.Append("  }\n");
            strresult.Append(" else\n");
            strresult.Append(" {\n");
            strresult.Append("  Session[\"SortDirection\"] = \"DESC\";");
            strresult.Append("\n");
            strresult.Append(" }\n");
            strresult.Append(" //===============\n");
            strresult.Append(" GridBind();\n");
            strresult.Append(" //===============\n");
            strresult.Append("}\n");
            strresult.Append("protected void grd" + Tablename.ToLower() + "_SortCommand(object source, DataGridSortCommandEventArgs e)\n");
            strresult.Append("{\n");
            strresult.Append("  GridBind(e.SortExpression);\n");
            strresult.Append("}\n");
            strresult.Append("}\n");
            txtResult.Text = strresult.ToString();




        }
    }
    #endregion
}