﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Threading;
using System.Web.Services;
using System.Text;
public partial class _Default : System.Web.UI.Page
{
    public string Database_Name;

    #region "-------------Page Events---------------"
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect("login.aspx");
        }
        SqlDataAdapter da = new SqlDataAdapter("select * from sysdatabases", Coneection.cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (!IsPostBack)
        {
            SwaBindcontrols.BindDropDownList(dropdatabase, ds.Tables[0], "name", "dbid");

        }

        //=============Code for calculating Number of tables============
        ds.Clear();
        Database_Name = dropdatabase.SelectedItem.Text;
        string query = "use " + Database_Name + " select * from sys.tables";
        SqlDataAdapter datables = new SqlDataAdapter(query, Coneection.cn);
        datables.Fill(ds);
        spntables.InnerText = ds.Tables[0].Rows.Count.ToString();
        StringBuilder strtablehtml = new StringBuilder("<table class='table table-hover'><thead><tr><th>Table Name</th><th>Create Date</th></tr></thead><tbody>");
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            strtablehtml.Append("<tr>");
            strtablehtml.Append("<td>");
            strtablehtml.Append(ds.Tables[0].Rows[i]["name"].ToString());
            strtablehtml.Append("</td>");

            strtablehtml.Append("<td>");
            strtablehtml.Append(String.Format("{0:dd-MMM-yyyy}", Convert.ToDateTime(ds.Tables[0].Rows[i]["create_date"])));

            strtablehtml.Append("</td>");
            strtablehtml.Append("</tr>");
        }
        strtablehtml.Append("</tbody></table>");
        divtables.InnerHtml = strtablehtml.ToString();
        //===================================================================
        //=============Code for calculating Number of Procedures============
        ds.Clear();
        Database_Name = dropdatabase.SelectedItem.Text;
        query = "use " + Database_Name + " select * from sys.procedures";
        SqlDataAdapter daprocedure = new SqlDataAdapter(query, Coneection.cn);
        daprocedure.Fill(ds);
        spnsp.InnerText = ds.Tables[0].Rows.Count.ToString();
        StringBuilder strprocedurehtml = new StringBuilder("<table class='table table-hover'><thead><tr><th>Table Name</th><th>Create Date</th></tr></thead><tbody>");
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            strprocedurehtml.Append("<tr>");
            strprocedurehtml.Append("<td>");
            strprocedurehtml.Append(ds.Tables[0].Rows[i]["name"].ToString());
            strprocedurehtml.Append("</td>");

            strprocedurehtml.Append("<td>");
            strprocedurehtml.Append(String.Format("{0:dd-MMM-yyyy}", Convert.ToDateTime(ds.Tables[0].Rows[i]["create_date"])));

            strprocedurehtml.Append("</td>");
            strprocedurehtml.Append("</tr>");
        }
        strprocedurehtml.Append("</tbody></table>");
        divProcedure.InnerHtml = strprocedurehtml.ToString();
        //===================================================================
        ds.Clear();
        Database_Name = dropdatabase.SelectedItem.Text;
        query = "use " + Database_Name + " SELECT name AS function_name,create_date,SCHEMA_NAME(schema_id) AS schema_name,type_desc FROM sys.objects WHERE type_desc LIKE '%FUNCTION%';";
        SqlDataAdapter dafunction = new SqlDataAdapter(query, Coneection.cn);
        dafunction.Fill(ds);
        spnfunction.InnerText = ds.Tables[0].Rows.Count.ToString();

        StringBuilder strfunctionhtml = new StringBuilder("<table class='table table-hover'><thead><tr><th>Table Name</th><th>Create Date</th></tr></thead><tbody>");
        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
        {
            strfunctionhtml.Append("<tr>");
            strfunctionhtml.Append("<td>");
            strfunctionhtml.Append(ds.Tables[0].Rows[i]["function_name"].ToString());
            strfunctionhtml.Append("</td>");

            strfunctionhtml.Append("<td>");
            strfunctionhtml.Append(String.Format("{0:dd-MMM-yyyy}", Convert.ToDateTime(ds.Tables[0].Rows[i]["create_date"])));

            strfunctionhtml.Append("</td>");
            strfunctionhtml.Append("</tr>");
        }
        strfunctionhtml.Append("</tbody></table>");
        divFunction.InnerHtml = strfunctionhtml.ToString();

    }
    #endregion

    #region "------------Control Events--------------"
    protected void dropdatabase_SelectedIndexChanged(object sender, EventArgs e)
    {
        Database_Name = dropdatabase.SelectedItem.Text;
        string query = "use " + Database_Name + " select * from sys.tables";
        SqlDataAdapter da = new SqlDataAdapter(query, Coneection.cn);
        DataSet dsTables = new DataSet();
        da.Fill(dsTables);
        SwaBindcontrols.BindDropDownList(Tables, dsTables.Tables[0], "name", "object_id");
    }
    protected void btngenrate_Click(object sender, EventArgs e)
    {
        string Created_By = String.Empty;
        Created_By = cmbname.SelectedItem.Text;
        string Result = string.Empty;
        string ResultSelectAll = string.Empty;
        string ResultSelectById = string.Empty;
        string ResultUpdate = string.Empty;
        string DeleteResult = string.Empty;
        string SelectById = string.Empty;
        string DeleteBystr = string.Empty;
        string Insertstr = string.Empty;
        string Tablename = Tables.SelectedItem.Text;
        string query = "use " + dropdatabase.SelectedItem.Text + " select top 1 * from " + Tablename;
        DataSet ds = new DataSet();
        ds = SwaDataAdapter.GetDatasetFromQuery(query);
        ArrayList arcolumnsname = new ArrayList();
        arcolumnsname = TableColumns.GetallColumnsnames(ds.Tables[0]);
        ResultSelectAll = CreateProcedure.SelectAllSp(Tablename, arcolumnsname, Created_By);
        ResultUpdate = CreateProcedure.GetUpdateSp(dropdatabase.SelectedItem.Text, Tablename, arcolumnsname, Created_By);
        DeleteResult = CreateProcedure.Delete_Sp(Tablename, arcolumnsname, Created_By);
        SelectById = CreateProcedure.SelectById(Tablename, arcolumnsname, Created_By);
        DeleteBystr = CreateProcedure.DeleteById(Tablename, arcolumnsname, Created_By);
        Insertstr = CreateProcedure.Insertall(dropdatabase.SelectedItem.Text, Tablename, arcolumnsname, Created_By);

        Result = Insertstr + "\n" + ResultUpdate + "\n" + DeleteResult + "\n" + DeleteBystr + "\n" + ResultSelectAll + "\n" + SelectById;
        //Result = ResultSelectAll + "\n" + SelectById + "\n" + ResultUpdate + "\n" + DeleteResult + "\n" + DeleteBystr+"\n"+Insertstr;
        txtResult.Text = Result;
    }
    #endregion


    public static string DataTableToJSONWithStringBuilder(DataTable table)
    {
        var JSONString = new StringBuilder();
        if (table.Rows.Count > 0)
        {
            JSONString.Append("[");
            for (int i = 0; i < table.Rows.Count; i++)
            {
                JSONString.Append("{");
                for (int j = 0; j < table.Columns.Count; j++)
                {
                    if (j < table.Columns.Count - 1)
                    {
                        JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\":" + "\"" + table.Rows[i][j].ToString() + "\",");
                    }
                    else if (j == table.Columns.Count - 1)
                    {
                        JSONString.Append("\"" + table.Columns[j].ColumnName.ToString() + "\":" + "\"" + table.Rows[i][j].ToString() + "\"");
                    }
                }
                if (i == table.Rows.Count - 1)
                {
                    JSONString.Append("}");
                }
                else
                {
                    JSONString.Append("},");
                }
            }
            JSONString.Append("]");
        }
        return JSONString.ToString();
    }  


    #region "-----------Web Methods-------------------"
    [WebMethod]
    public static string SqlConnect(string server, string username, string password)
    {

        string strconn = "server=" + server + ";uid=" + username + ";pwd=" + password + ";database=master";
        Coneection.cn = new SqlConnection(strconn);
        SqlConnection tempcon = Coneection.cn;
        try
        {
            Coneection.cn.Open();

            return "Connected";
        }
        catch
        {
            Coneection.cn = tempcon;
            Coneection.cn.Close();
            return "Error Occured";
        }
        finally
        {
            Coneection.cn.Close();
        }
    }
    [WebMethod]
    public static void Logout()
    {
        HttpContext.Current.Session["UserId"] = null;
        HttpContext.Current.Session["pwd"] = null;
    }

    #endregion

}