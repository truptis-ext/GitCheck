﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Text;
using BlackBeltCoder.JavaFormatter;

public partial class Angular : System.Web.UI.Page
{
    public string Database_Name;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect("login.aspx");
        }
        SqlDataAdapter da = new SqlDataAdapter("select * from sysdatabases order by name", Coneection.cn);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (!IsPostBack)
        {
            SwaBindcontrols.BindDropDownList(dropdatabase, ds.Tables[0], "name", "dbid");
            Bindusers();
        }
    }
    protected void dropdatabase_SelectedIndexChanged(object sender, EventArgs e)
    {
        Database_Name = dropdatabase.SelectedItem.Text;
        string query = "use " + Database_Name + " select * from sys.tables order by name";
        SqlDataAdapter da = new SqlDataAdapter(query, Coneection.cn);
        DataSet dsTables = new DataSet();
        da.Fill(dsTables);
        SwaBindcontrols.BindDropDownList(Tables, dsTables.Tables[0], "name", "object_id");
    }

    public void Bindusers()
    {

        SqlDataAdapter da = new SqlDataAdapter("Select Id, username, password, IsAdmin from tbl_user", Coneection.cn1);
        DataSet ds = new DataSet();
        da.Fill(ds);
        cmbname.DataTextField = "username";
        cmbname.DataValueField = "Id";
        cmbname.DataSource = ds.Tables[0];
        cmbname.DataBind();
        cmbname.Items.FindByValue(Session["UserId"].ToString()).Selected = true;
    }
    protected void btngenrate_Click(object sender, EventArgs e)
    {
        Database_Name = dropdatabase.SelectedItem.Text;
        if (Tables.SelectedItem == null)
        {
            MessageBox.Show("Please Select Table");
            return;
        }
        string strtablename = Tables.SelectedItem.Text;
        StringBuilder strresult = new StringBuilder();

        string query = "use " + Database_Name + " exec sp_columns " + strtablename;
        SqlDataAdapter da = new SqlDataAdapter(query, Coneection.cn);
        DataSet dsTables = new DataSet();
        da.Fill(dsTables);
        strresult.Append("var app = angular.module('" + Tables.SelectedItem.Text + "App', []);\n");
        strresult.Append("app.controller('" + Tables.SelectedItem.Text + "Controller', function ($scope, httpcombinedservices) {\n");
        strresult.Append("function Get" + Tables.SelectedItem.Text + "() {\n");
        strresult.Append("httpcombinedservices.Get" + Tables.SelectedItem.Text + "().then(function (responce) {\n");
        strresult.Append("$scope.allRows = JSON.parse(responce.data.d); \n");
        strresult.Append("var totalPages = $scope.allRows.length / 10;\n");
        strresult.Append("if (($scope.allRows.length % 10) > 0) {\n");
        strresult.Append("totalPages = parseInt($scope.allRows.length / 10) + 1;\n");
        strresult.Append("}\n");
        strresult.Append("else {\n");
        strresult.Append("totalPages = $scope.allRows.length / 10;\n");
        strresult.Append("}\n");
        strresult.Append("if (angular.isUndefined($scope.selectedPage)) {\n");
        strresult.Append("$scope.selectedPage = 1;\n");
        strresult.Append("}\n");
        strresult.Append("$scope.pageChanged();\n");
        strresult.Append("$scope.Pages = _.range(1, totalPages + 1);\n");

        strresult.Append("});\n");
        strresult.Append("}\n");
        strresult.Append("$scope.init = function () {\n");
        strresult.Append("Get" + Tables.SelectedItem.Text + "();\n");
        strresult.Append("$scope.editMode = false;\n");
        strresult.Append("}\n");
        strresult.Append("$scope.edit = function (rowObject) {\n");
        strresult.Append("$scope.editMode = true;\n");
        strresult.Append("AddMode(false, true);\n");

        string Tablename = Tables.SelectedItem.Text;
        query = "use " + dropdatabase.SelectedItem.Text + " select top 1 * from " + Tablename;
        DataSet ds = new DataSet();
        ds = SwaDataAdapter.GetDatasetFromQuery(query);
        ArrayList arcolumnsname = new ArrayList();
        arcolumnsname = TableColumns.GetallColumnsnames(ds.Tables[0]);

        for (int i = 0; i < arcolumnsname.Count; i++)
        {
            strresult.Append("$scope." + arcolumnsname[i].ToString() + " = " + "rowObject." + arcolumnsname[i].ToString() + ";\n");
        }
        strresult.Append("}\n");


        strresult.Append("$scope.delete = function (Id) {\n");
        strresult.Append("if (confirm('Do you want to delete this record.')) {\n");
        strresult.Append("httpcombinedservices.Delete" + Tablename + "(Id).then(function (responce) {\n");


        strresult.Append("Get" + Tablename + "();\n");
        strresult.Append("if (responce.data.d > 0) {\n");
        strresult.Append("alert('Record deleted sucessfully');\n");
        strresult.Append("}\n");
        strresult.Append("});\n");

        strresult.Append("}\n");
        strresult.Append("}\n");


        strresult.Append("$scope.addNewRecord = function () {\n");
        strresult.Append("$scope.editMode = true;\n");
        strresult.Append("$scope.clear();\n");
        strresult.Append("AddMode(true, false);\n");
        strresult.Append("setUntouched($scope.vessel)\n");
        strresult.Append("}\n");



        strresult.Append("$scope.cancel = function () {\n");
        strresult.Append("$scope.editMode = false;\n");
        strresult.Append("}\n");

        strresult.Append("$scope.Update = function () {\n");

        strresult.Append("var myObj={};\n");
        for (int i = 0; i < arcolumnsname.Count; i++)
        {
            strresult.Append("myObj['" + arcolumnsname[i].ToString() + "'] = " + "$scope." + arcolumnsname[i].ToString() + ";\n");
        }

        strresult.Append("httpcombinedservices.Update" + strtablename + "(myObj).then(function (responce) {\n");
        strresult.Append("if (responce.data.d > 0) {\n");
        strresult.Append("Get" + strtablename + "();\n");
        strresult.Append("$scope.editMode = false;\n");
        strresult.Append("alert('Record Updated sucessfully');\n");
        strresult.Append("}\n");
        strresult.Append("});\n");

        strresult.Append("}\n");


        strresult.Append("$scope.Save = function () {\n");

        strresult.Append("var myObj={};\n");
        for (int i = 1; i < arcolumnsname.Count; i++)
        {
            strresult.Append("myObj['" + arcolumnsname[i].ToString() + "'] = " + "$scope." + arcolumnsname[i].ToString() + ";\n");
        }

        strresult.Append("httpcombinedservices.AddNew" + strtablename + "(myObj).then(function (responce) {\n");
        strresult.Append("if (responce.data.d > 0) {\n");
        strresult.Append("Get" + strtablename + "();\n");
        strresult.Append("$scope.editMode = false;\n");
        strresult.Append("alert('Record Added sucessfully');\n");
        strresult.Append("}\n");
        strresult.Append("});\n");

        strresult.Append("}\n");



        strresult.Append("$scope.clear = function () {\n");
        for (int i = 1; i < arcolumnsname.Count; i++)
        {
            strresult.Append("$scope." + arcolumnsname[i].ToString() + "= '' ;\n");
        }
        strresult.Append("}\n");


        strresult.Append("$scope.sortColumn = function (columnName) {\n");
        strresult.Append("$scope.orderByColumn = columnName;\n");
        strresult.Append("if ($scope.sortDirection) {\n");
        strresult.Append("$scope.sortDirection = false;\n");
        strresult.Append("}\n");
        strresult.Append("else {\n");
        strresult.Append("$scope.sortDirection = true;\n");
        strresult.Append("}\n");
        strresult.Append("}\n");


        strresult.Append("$scope.pageChanged = function()\n");
        strresult.Append("{\n");
        strresult.Append("var to = $scope.selectedPage * 10;\n");
        strresult.Append("var from = to - 10;\n");
        strresult.Append("$scope.rows = $scope.allRows.slice(from, to);\n");
        strresult.Append("}\n");

        strresult.Append("function AddMode(isAddmode, isUpdateMode) {\n");
        strresult.Append("$scope.showAddButton = isAddmode;\n");
        strresult.Append("$scope.showUpdateButton = isUpdateMode;\n");
        strresult.Append("}\n");

        strresult.Append("});");
        txtResult.Text = strresult.ToString();

        txthtml.Text = Angularjs.GetHtml(Database_Name, strtablename, arcolumnsname);
        txtwebmethod.Text = Angularjs.GetWebMethod(Database_Name, strtablename, arcolumnsname);

        JavaFormatter fmt = new JavaFormatter();
        fmt.OpenBraceOnNewLine = true;
        fmt.NewLineBeforeLineComment = true;
        fmt.NewLineBeforeInlineComment = true;
        fmt.NewLineAfterInlineComment = true;
        txtResult.Text = fmt.Format(txtResult.Text);

        txtservices.Text = fmt.Format(Angularjs.GetService(Database_Name, strtablename, arcolumnsname));

    }
}